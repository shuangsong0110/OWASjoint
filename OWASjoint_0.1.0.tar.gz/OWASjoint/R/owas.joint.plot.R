#' @title Main function
#' @description Run OWAS-JOINT. Please NOTE that OWAS-joint is based on the results of OWAS. Therefore, one need to perform OWAS analysis before aggregating with OWAS-joint.
#' @param trait trait name
#' @param path.owas specify the output path of the OWAS analysis
#' @param path.output specify the output path of the figure
#' @param chr chromosome, can be a integer or vector from 1 to 22, default=1:22
#' @param format  pdf/jpg/tiff
#'
#'
#' @import  data.table stats utils
#' @export
#'
#'
owas.joint.plot <- function(trait='test',path.owas,path.output, chr=1:22, format='jpg'){
  chr0 <- chr
  ct <- 'JOINT'
  dir.create(path.output,recursive=T)
  setwd(path.output)
  path0 <- path.owas
  if(!file.exists('bedfile_5kb.txt')){
  system('wget -O bedfile_5kb.txt https://cloud.tsinghua.edu.cn/f/7524fb35b88c468dbc02/?dl=1 --no-check-certificate')
  }
    pos <- fread('bedfile_5kb.txt')
  pos1 <- data.frame(SNP=paste0(pos$gene,'_RE',pos$index),
                     chr=pos$chr,pos=floor((pos$start+pos$end)/2),order=1:nrow(pos))
  for(ctype in ct){
    print(ct)
    for(chr in chr0){
      if(chr==chr0[1]){
        stats <- fread(paste0(path0,'/ctype/JOINT/chr',chr,'/',trait,'/1_gene_stats.txt'))
      }else{
        stats <- rbind(stats,  fread(paste0(path0,'/ctype//JOINT/chr',chr,'/',trait,'/1_gene_stats.txt')))
      }
    }
    stats$SNP <- paste0(stats$gene,'_RE',stats$ind)
    dat.temp <- stats[,c('SNP','p_g')]
    colnames(dat.temp)[2] <- ctype
    #if(ctype=='A549'){
    pos2 <- pos1[pos1$chr%in%chr0,]
    #}
    pos2 <- merge(pos2,dat.temp,by='SNP',all.x=T)
  }
  pos3 <- pos2[order(pos2$order),-4]
  pos3[is.na(pos3)] <- 1
  col2 <- c("dodgerblue4",
            "deepskyblue")
  SNPs <-  pos3[pos3$ACAT_part < 5e-8, 1]
  setwd(path.output)
  #pos3 <- pos3[pos3$chr%in%chr,]
  pos3$JOINT[pos3$JOINT<1e-200] <- 1e-200
  CMplot(pos3,type="p",plot.type="m",LOG10=TRUE,
         #highlight=SNPs,highlight.type="h",
         col=col2,
         #highlight.col="darkblue",highlight.cex=1.2,highlight.pch=19,
         file=format,dpi=300,file.output=TRUE,verbose=TRUE,width=12,height=8,
         threshold=c(5e-8),threshold.lty=c(2),threshold.lwd=c(2),
         threshold.col=c("red"))
}
