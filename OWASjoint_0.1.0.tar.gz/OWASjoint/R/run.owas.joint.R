#' @title Main function
#' @description Run OWAS-JOINT. Please NOTE that OWAS-joint is based on the results of OWAS. Therefore, one need to perform OWAS analysis before aggregating with OWAS-joint.
#' @param ctype celltype, a vector including all ctypes that need to be aggregated
#' @param weight optional, a vector with the same length with ctype, to specify the ACAT weight for each cell type. Default: rep(1/L, L), where L is the length of cell type.
#' @param trait trait name
#' @param path.owas specify the output path of the OWAS analysis (should be prepared beforehand)
#' @param chr chromosome, can be a integer or vector from 1 to 22, default=1:22
#'
#'
#' @import  data.table stats utils rMVP ACAT
#' @export
#'
#'
run.owas.joint <- function(ctype,weight=NULL, trait='test',path.owas, chr=1:22){
  options(scipen=300)
   ctype0 <- ctype
  chr0 <- chr
  path0=path.owas
  path.output=path.owas
  for(ctype in ctype0){
    for(chr in chr0){
      if(!file.exists(paste0(path0,"/ctype/",ctype,"/chr",chr,"/",trait,
                             "/1_gene_stats.txt")  )){
        stop(paste0('The OWAS file for ',trait,' of cell type ', ctype,
              ' on chromosome ',chr,' does not exist. Please specify the correct path.owas.'))
      }
    }
  }
  if(is.null(weight)){
    weight=rep(1,length(ctype))
  }
  setwd(path.output)
  # system('wget -O bedfile_5kb.txt https://cloud.tsinghua.edu.cn/f/7524fb35b88c468dbc02/?dl=1 --no-check-certificate')
  # pos <- fread('bedfile_5kb.txt')
  # pos$seg <- paste0(pos$gene,'_RE',pos$index)
  for(chr in chr0){
    print(paste('Running algorithms on chromosom', chr))
    # rr <- which(as.numeric(pos$chr)==chr)
    # pos1 <- pos[rr,]
    # pos1$id <- 1:nrow(pos1)
    for(ctype in ctype0){
      print(ctype)
      temp <- fread(paste0(path0,"/ctype/",ctype,"/chr",chr,"/",trait,
                           "/1_gene_stats.txt"))
      temp$seg <- paste0(temp$gene,'_RE',temp$ind)
      if(ctype==ctype0[1]){
        #colnames(temp)[which(colnames(temp)=='p_g')] <- ctype
        temp$p_g1 <- temp$p_g
        colnames(temp)[which(colnames(temp)=='p_g1')] <- ctype
        temp1 <- temp
        pos1 <- temp1

      }else{
      temp1 <- temp[,c('seg','p_g')]
      colnames(temp1)[2] <- ctype
      pos1 <- merge(pos1,temp1,by='seg',all.x=T)

      }
    }
    pos1 <- pos1[order(pos1$order),]
    tt1 <- ncol(pos1)-length(ctype0)+1
    tt2 <- ncol(pos1)
    mat <- as.matrix(pos1[,tt1:tt2])
    mat[which(is.na(mat))] <- 1
    weight.mat <- matrix(weight,nrow=length(ctype0),ncol=nrow(pos1))
    acat.p <- ACAT(t(mat),weights=weight.mat)
    res <- pos1[,c(1:8,10:11)]
    #colnames(res)[1] <- 'gene'
    res$p_g <- acat.p
    #acat.p[acat.p<1e-300] <- 1e-300
   # res <- res[which(acat.p!=1),]
    dir.create(  paste0(path0,"/ctype/JOINT/chr",chr,"/",trait),recursive = T)
    write.table(res,  paste0(path0,"/ctype/JOINT/chr",chr,"/",trait,
                             "/1_gene_stats.txt"),quote=F,row.names=F,col.names=T)
    gene_stats.sig <- res[res$p_g<0.05,]
    write.table(gene_stats.sig,paste0(path0,"/ctype/JOINT/chr",chr,"/",trait,
                                      "/1_gene_stats_sig.txt"),quote=F,col.names = T,row.names=F)

  }
  return(gene_stats.sig)
}



