#' @title Main function
#' @description Run OWAS-JOINT. Please NOTE that OWAS-joint is based on the results of OWAS. Therefore, one need to perform OWAS analysis before aggregating with OWAS-joint.
#' @param ctype celltype, can be either an element or a vector including mutliple ctypes. We suggest less than four cell types for better visualization
#' @param trait trait name
#' @param path.owas specify the output path of the OWAS analysis
#' @param path.output specify the output path of the figure
#' @param chr chromosome, can be a integer or vector from 1 to 22, default=1:22
#' @param format  pdf/jpg/tiff
#'
#'
#' @import  data.table stats utils
#' @export
#'
#'
owas.single.plot <- function(trait='test', ctype, path.owas,path.output, chr=1:22, format='jpg'){
  chr0 <- chr
  setwd(path.output)
  path0 <- path.owas
  ct <- ctype
  if(!file.exists('bedfile_5kb.txt')){
    system('wget -O bedfile_5kb.txt https://cloud.tsinghua.edu.cn/f/7524fb35b88c468dbc02/?dl=1 --no-check-certificate')
  }
  pos <- fread('bedfile_5kb.txt')
  pos1 <- data.frame(SNP=paste0(pos$gene,'_RE',pos$index),
                     chr=pos$chr,pos=(pos$start+pos$end)/2,order=1:nrow(pos))


  for(ctype in ct){
    print(ctype)
    for(chr in chr0){
      if(chr==chr0[1]){
        stats <- fread(paste0(path0,'/ctype/',ctype,'/chr',chr,'/',trait,'/1_gene_stats.txt'))
      }else{
        stats <- rbind(stats,  fread(paste0(path0,'/ctype/',ctype,'/chr',chr,'/',trait,'/1_gene_stats.txt')))
      }
    }
    stats$SNP <- paste0(stats$gene,'_RE',stats$ind)
    dat.temp <- stats[,c('SNP','p_g')]
    dat.temp$p_g[ dat.temp$p_g<1e-200] <- 1e-200

    colnames(dat.temp)[2] <- ctype
    if(ctype==ct[1]){
      pos2 <- pos1
    }
    pos2 <- merge(pos2,dat.temp,by='SNP',all.x=T)
  }
  pos3 <- pos2[order(pos2$order),-4]
  pos3[is.na(pos3)] <- 1
  setwd(path.output)
  if(length(ct<=4)){
    col=matrix(c("#be4e75","#f498af","#5169b0","#b6c7f8","#d1843f","#ffcea3",'#6e9a95','#a2d8d2')[1:(2*length(ct))],
               length(ct),2,byrow=T)
    CMplot(pos3,type="p",plot.type="c",chr.labels=paste("Chr",c(1:22),sep=""),r=0.4,cir.legend=TRUE,
           outward=FALSE,cir.legend.col="grey60",cir.chr.h=1.3,chr.den.col="grey60",file="pdf",
           memo="",dpi=300,file.output=TRUE,verbose=TRUE,width=10,height=10,col=col)
  }else{
    CMplot(pos3,type="p",plot.type="c",chr.labels=paste("Chr",c(1:22),sep=""),r=0.4,cir.legend=TRUE,
           outward=FALSE,cir.legend.col="grey60",cir.chr.h=1.3,chr.den.col="grey60",file="pdf",
           memo="",dpi=300,file.output=TRUE,verbose=TRUE,width=10,height=10)
  }
}
